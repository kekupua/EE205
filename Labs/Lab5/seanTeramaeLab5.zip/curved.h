#pragma once
#include <vector>
using namespace std;
// Function Prototypes
float average(vector<float> grades);
float standardDeviation(vector<float> grades, float average);
void printGrades(vector<float>, float average, float std);