/* This  runs on Visual Studio
 so make sure to use scanf instead of  scanf_s,
and comment out  getch() if you are on Unix. 
*/

/* By:		Sean Teramae
 * Login:	teramae8
 * Date:	1/10/2017
 * Section:	1		*/

#include <stdio.h>
#include <math.h>
#include "sphere.h"

#define PI  3.14

int main() {
	double r;
	double s = 0;
	double v = 0;
	
	printf("Enter radius in inches\n");
	scanf("%lf", &r);

	//Outline
	printf("\n\nSphere parameters: \n\n");
	printf("Radius(in)\tArea(in^2)\tVolume(in^3)\n");
	int result = calcAreaAndVolume(r, &s, &v);
	
	//Pretty Print
	printf("=================================================\n");
	printf("%.2f\t\t%.2f\t\t%.2f\n\n", r, s, v);

	return 0;

}

int calcAreaAndVolume(double rad, double *parea, double *pvolume) {
	*parea = 4.0*pow(rad, 2.0)*PI;
	*pvolume = (4.0/3.0)*rad*rad*rad*PI;
	return 0;
}

