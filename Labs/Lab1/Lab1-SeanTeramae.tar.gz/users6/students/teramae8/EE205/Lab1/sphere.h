#include <stdio.h>
#include <math.h>

#define PI 3.14

/* Name:	Sean Teramae
 * Login:	teramae8
 * Date: 	1/10/2017
 * Section: 	1		*/

int calcAreaAndVolume(double rad, double *parea, double *pvolume);

