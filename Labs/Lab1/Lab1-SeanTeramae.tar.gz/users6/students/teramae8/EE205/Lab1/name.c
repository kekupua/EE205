/* By:		Sean Teramae
 * Login:	teramae8
 * Date:	1/10/2017
 * Section:	1		*/

#include<stdio.h>
#include<string.h>

// Define Structure
typedef struct id{
	char name[30];
	int age;
	float weight;
} id;

void printID(id user);

int main(){

	// Declare user
	id me = {"", 19, 137.32};
	strcpy(me.name,"Sean\0");

	// Print to screen
	printID(me);
}

void printID(id user){
	printf("%s is %d and weighs %.2flbs.\n", user.name, user.age, user.weight);
}
