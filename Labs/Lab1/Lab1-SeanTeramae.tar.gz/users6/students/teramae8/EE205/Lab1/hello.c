/* By:		Sean Teramae
 * Login:	teramae8
 * Date:	1/10/2017
 * Section:	1		*/

#include <stdio.h>

int main(){
  // Output to console
  printf("Hello World\n");
  return 0;
}
